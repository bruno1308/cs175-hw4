======INSTRUCTIONS======

1) Extract Hw5Server.zip, compile the .java files and execute the SnakeServer file, it will start the server locally on your machine (I don't have an online dedicated server). Make sure scores.txt is in the build path, because the server will load/save high scores from there.

2) Extract Hw5Client. Open the Connection.java file and, in the constructor (line 35), where you see:
 this.IP = "10.1.10.24";
 change it to your local IP (ipconfig/ifconfig)

3) Run the Android project.