package edu.sjsu.cs175_hw4;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

public class MazeGenerator {
	Vector<Integer> result = new Vector<Integer>();
	Set<Integer> openings = new HashSet<Integer>();
	 
	static int diff=0;
	static int h,w;
	/**
	 * Generates new mazes randomly given a certain difficulty
	 */
	public Vector<Integer> generate(int dif,int h,int w){
		MazeGenerator.diff = dif;
		MazeGenerator.h = h;
		MazeGenerator.w= w;
		Set<Integer> blockings = new HashSet<Integer>();
		int myvec[] = {2,3,3,4,5,5,6,7,8,9};
		int blocking_number;
		if(dif>=10) blocking_number = myvec[9];
		else blocking_number = myvec[dif];
		
		for(int k=blocking_number;k>0;--k) blockings.add(randInt(4, w-3,blockings,0));
		
		int usable_rows = h-12-5;
		int openings_number = (usable_rows/10)*((6-dif));
		if(openings_number <=0) openings_number=1;
		
			
			for(int i=0; i<w;++i){
				openings.clear();
				for(int k=openings_number;k>0;--k)openings.add(randInt(6,h-11,blockings,1));
		       	  for(int j=0;j<h;++j){
		       		if(j>h-12 || j<5) continue;
		       		  if(blockings.contains(i) ){
		       				  if(!openings.contains(j))		       				  
		       					  result.add(h*i +j);		       			  
		       		  }
		       	  }
		    }
			
			blockings.clear();
		return result;
		
		
	}
	public static int randInt(int min, int max,Set<Integer> blockings,int op) {
		int cont=0;
	    // NOTE: Usually this should be a field rather than a method
	    // variable so that it is not re-seeded every call.
	    Random rand = new Random();
	    
	    // nextInt is normally exclusive of the top value,
	    // so add 1 to make it inclusive
	    int randomNum = rand.nextInt((max - min) + 1) + min;
	    if(op==0){
	    Set<Integer> mycopy = new HashSet<Integer>();
		mycopy.addAll(blockings);
		mycopy.add(0);
		mycopy.add(w-1);
	    Iterator<Integer> iterator = mycopy.iterator(); 
	    while(iterator.hasNext()){
	    	int next = (Integer) iterator.next();
	    	while(diff <6 && Math.abs(randomNum-next)<7-diff){
	    		randomNum = rand.nextInt((max - min) + 1) + min;
	    		iterator = mycopy.iterator();
	    		cont++;
	    		if(cont==10) break;
	    	}
	    	cont=0;
	    	
	    }
	    }
	    return randomNum;
	}

}
